"""Module with Sequences, mostly for Keras models."""
__all__ = []