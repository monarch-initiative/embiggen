from embiggen.feature_preprocessors.graph_convolution import GraphConvolution

__all__ = [
    "GraphConvolution",
]