"""Current version of package embiggen"""
__version__ = "0.8.0"
