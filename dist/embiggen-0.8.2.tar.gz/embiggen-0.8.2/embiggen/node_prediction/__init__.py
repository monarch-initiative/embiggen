"""Models for node label prediction."""
from .nolan import NoLaN

__all__ = ["NoLaN"]
