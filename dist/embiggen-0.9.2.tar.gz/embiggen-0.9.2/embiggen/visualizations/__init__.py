"""Module containing objects for visualization of the embeddings."""
from .graph_visualization import GraphVisualization

__all__ = [
    "GraphVisualization"
]
