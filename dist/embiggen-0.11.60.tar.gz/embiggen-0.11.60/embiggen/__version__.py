"""Current version of package Embiggen."""
__version__ = "0.11.60"