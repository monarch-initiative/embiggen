"""Module containing objects for visualization of the embeddings."""
from embiggen.visualizations.graph_visualizer import GraphVisualizer

__all__ = [
    "GraphVisualizer"
]
