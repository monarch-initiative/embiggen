"""Current version of package embiggen"""
__version__ = "0.11.7"
